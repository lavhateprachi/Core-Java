package com.utils;

import java.time.LocalDate;
import java.util.ArrayList;

import com.core.Stock;

public class PopulateData {
	
	public static ArrayList<Stock> populateData()
	{
		ArrayList<Stock> stock = new ArrayList<Stock>();
		
		stock.add(new Stock("education", "accenture", 10000, LocalDate.parse("2021-12-25"), 30));
		stock.add(new Stock("charity", "TCS", 2000, LocalDate.parse("2020-02-16"), 20));
		stock.add(new Stock("education", "synechron", 5000, LocalDate.parse("2022-05-15"), 10));
		stock.add(new Stock("market", "DXC", 20000, LocalDate.parse("2019-09-01"), 10));
		
		return stock;
	}

}
