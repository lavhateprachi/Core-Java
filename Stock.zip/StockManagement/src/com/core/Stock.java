package com.core;

import java.time.LocalDate;

public class Stock {
	private int stockId;
	private String stockName;
	private String companyName;
	private double price;
	private LocalDate closingDate;
	private int qty;
	private static int id;
	
	static {
		id=1;
	}
	public Stock(String stockName, String companyName, double price, LocalDate closingDate, int qty) {
		super();
		this.stockId = id++;
		this.stockName = stockName;
		this.companyName = companyName;
		this.price = price;
		this.closingDate = closingDate;
		this.qty = qty;
	}
	
	
	public int getStockId() {
		return stockId;
	}
	public void setStockId(int stockId) {
		this.stockId = stockId;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public LocalDate getClosingDate() {
		return closingDate;
	}
	public void setClosingDate(LocalDate closingDate) {
		this.closingDate = closingDate;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}


	@Override
	public String toString() {
		return "Stock [stockId=" + stockId + ", stockName=" + stockName + ", companyName=" + companyName + ", price="
				+ price + ", closingDate=" + closingDate + ", qty=" + qty + "]";
	}
	
	
	public Stock(int id)
	{
	this.stockId=id;
	}

	public Stock(String name)
	{
	this.stockName=name;
	}

	@Override
	public boolean equals(Object obj) {
		// TODO Auto-generated method stub
		
		Stock t = (Stock)obj; 
		return this.stockName.equals(t.stockName);
	}
	
	
}
