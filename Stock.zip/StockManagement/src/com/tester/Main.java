package com.tester;

import java.util.ArrayList;
import java.util.Scanner;

import com.core.*;
import com.utils.PopulateData;
import com.utils.ValidationRules;
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Stock> stockList = new ArrayList<Stock>();
		
		try(Scanner sc = new Scanner(System.in))
		{
			boolean exit=false;
			
			while(!exit)
			{
				System.out.println("Option: \n1.Add Stock using Populate"
						+ "\n2.Add new stock"
						+ "\n3.Display Stock Based on Company"
						+ "\n4.Purchase Stocks"
						+ "\n5.Sell Stocks"
						+ "\n0.Exit");
				
				
				System.out.println("Enter Choice:");
				try {
					switch(sc.nextInt())
					{
							case 1:
								stockList = PopulateData.populateData();
								stockList.forEach(s->System.out.println(s));
								break;
							case 2:
								System.out.println("Enter stockName,companyName,price,closingDate,quantity: ");
								Stock stock = ValidationRules.validateInput(sc.next(),sc.next(),sc.nextDouble(),sc.next(),sc.nextInt(),stockList);
								stockList.add(stock);
								System.out.println("Stock inserted successfully...");
								break;
							case 3:
								System.out.println("Enter company name:");
								String name=sc.next();
								for(Stock s:stockList)
								{
									if(s.getCompanyName().equals(name))
									{
										System.out.println(s);
									}
									
								}
								break;
							case 4:
								System.out.println("Enter stockId and quantity");
								int id = sc.nextInt();
								int qty=sc.nextInt();
								
								
								break;
							case 0:
								exit=true;
								break;
								
					}
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
		}

	}

}
