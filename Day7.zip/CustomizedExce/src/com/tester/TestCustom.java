package com.tester;
import com.custom.*;
import java.util.Scanner;

import com.custom.Customer;

public class TestCustom {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		GrowableStack gs=new GrowableStack();
		//FixedStack fs = new FixedStack();
		
		
		Customer[] c = new Customer[stack.STACK_SIZE] ;
		   
			for(int i=0;i<c.length;i++)
			{
				System.out.println("Enter Data: ");
				c[i] = new Customer(sc.nextInt(),sc.next(),sc.next());
				gs.push(c[i]);
			}
			
			for(int i=0;i<GrowableStack.STACK_SIZE;i++)
			{
				c[i]=gs.pop();
				System.out.println(c[i]);
				
			}
	}

}
