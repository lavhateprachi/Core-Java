package com.custom;

public class FixedStack extends Customer implements stack {

	private int top;
	
	private Customer[] fs;
		public FixedStack()
		{
			top=-1;
			fs = new Customer[stack.STACK_SIZE];
		}
	
	
	public void push(Customer c1)
	{
		if(top==stack.STACK_SIZE-1)
		{
			System.out.println("Stack is full");
		}
		else
		{
			fs[++top]=c1;
			System.out.println(top);
		}
	}
	public Customer pop()
	{
		if(top==-1)
		{
			return null;
		}
		else
		{	
			System.out.println(top);
			return fs[top--];
		    
		}
			
	}

}
