package com.custom;

public interface stack {
	
	int STACK_SIZE=2;
	
	void push(Customer c);
	
	public Customer pop();

}
