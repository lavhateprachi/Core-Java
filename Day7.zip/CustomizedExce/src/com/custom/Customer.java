package com.custom;

public class Customer {
	private int id;
	private String name;
	private String address;
	
	Customer()
	{
		
	}
	
	public Customer(int id,String n,String adr)
	{
		this.id=id;
		name=n;
		address=adr;
	}
	
	public String toString()
	{
		return "Id : "+this.id+" Name : "+name+" Address : "+address;
	}

}
