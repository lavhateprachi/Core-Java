
package com.custom;

public class GrowableStack implements stack {

	 int top = -1;
	public  static int STACK_SIZE=2;
	private Customer[] fs =new Customer[STACK_SIZE] ;
	private Customer[] growableArray;
		
	
	public void push(Customer c1)
	{
		if(top<STACK_SIZE-1)
		{
			fs[++top] = c1;
		}
		
		else
		{
			//STACK_SIZE*=2;
			growableArray = new Customer[STACK_SIZE*2];
			
			for(int i = 0 ; i<fs.length;i++) {
				growableArray[i] = fs[i];
			}
			
			fs = growableArray;
			growableArray[++top] = c1;
		}
	}
	public Customer pop()
	{
		if(top==-1)
		{
			return null;
		}
		else
		{	
			System.out.println("In Pop(top):"+top);
			return growableArray[top--];
		    
		}	
	}
}
